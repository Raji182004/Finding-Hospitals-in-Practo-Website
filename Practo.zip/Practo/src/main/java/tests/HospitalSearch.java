package tests;
import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
 
// Excel handling
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
// Selenium and TestNG
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.*;
 
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.Duration;
 
public class HospitalSearch extends DriverSetup {
 
    public static ExtentReports extent;
    public static ExtentTest test;
 
    @BeforeSuite
    public void setupReport() {
        // Initializes the ExtentSparkReporter for HTML report generation
        ExtentSparkReporter spark = new ExtentSparkReporter("PractoTestReport.html");
        // Sets the report's theme, document title, and report name
        spark.config().setTheme(Theme.DARK);
        spark.config().setDocumentTitle("Practo Automation Report");
        spark.config().setReportName("Practo Hospital & Medicine Test");
 
        // Creates and attaches the reporter to the main ExtentReports object
        extent = new ExtentReports();
        extent.attachReporter(spark);
        // Adds system information to the report
        extent.setSystemInfo("Tester", "Rajagomathi S");
        extent.setSystemInfo("OS", System.getProperty("os.name"));
        extent.setSystemInfo("Java Version", System.getProperty("java.version"));
    }
 
    @Test
    public void practoAutomationTest() {
        // Creates a new test entry in the report
        test = extent.createTest("Practo Automation Test");
 
        try {
            String browser = "chrome";
            // Launches the specified browser
            launchBrowser(browser);
            ScreenshotUtil.capture(driver, "Browser Launched", test);
 
            // Navigates to the Practo website
            driver.get("https://www.practo.com");
            ScreenshotUtil.capture(driver, "Practo Home Page", test);
 
            JavascriptExecutor js = (JavascriptExecutor) driver;
            // Scrolls down the page to find the footer elements
            js.executeScript("window.scrollBy(0,1000)");
            ScreenshotUtil.capture(driver, "Scrolled Down", test);
 
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            // Waits for the "Search for Hospital" link to be clickable
            WebElement searchforhospital = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//*[@id=\"root\"]/div/div/footer/div/div[1]/div[2]/div[2]/a[3]/span")));
            // Highlights the element
            highlightElement(driver, searchforhospital);
            // Scrolls the element into view
            js.executeScript("arguments[0].scrollIntoView(true);", searchforhospital);
            // Clicks on the link
            searchforhospital.click();
            ScreenshotUtil.capture(driver, "Clicked on Hospital Search", test);
 
            String[] cities = {"Bangalore", "Chennai", "Hyderabad", "Mumbai", "Delhi"};
            List<String[]> topHospitals = new ArrayList<>();
 
            // Iterates through a list of cities to find the top hospital in each
            for (String city : cities) {
                // Sets the location in the search bar
                setLocation(driver, city);
                Thread.sleep(3000);
                // Retrieves the details of the top hospital
                String[] hospitalData = getTopHospital(driver);
 
                if (hospitalData != null) {
                    // Prints the hospital details to the console
                    System.out.println("City: " + city);
                    System.out.println("Hospital: " + hospitalData[0]);
                    System.out.println("Timing: " + hospitalData[1]);
                    System.out.println("Rating: " + hospitalData[2]);
                    System.out.println("-----------------------------");
 
                    // Stores the data for later use in Excel
                    topHospitals.add(new String[]{city, hospitalData[0], hospitalData[1], hospitalData[2]});
                    test.log(Status.INFO, "Hospital found in " + city + ": " + hospitalData[0]);
                } else {
                    System.out.println("No hospital data found for " + city);
                }
            }
 
            // Scrolls down the page again
            js.executeScript("window.scrollBy(0,1000)");
            ScreenshotUtil.capture(driver, "Scrolled to Practo Plus", test);
 
            // Waits for and clicks the "Practo Plus" link
            WebElement practo = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Practo Plus")));
            // Highlights the element
            highlightElement(driver, practo);
            js.executeScript("arguments[0].scrollIntoView(true);", practo);
            practo.click();
            ScreenshotUtil.capture(driver, "Clicked on Practo Plus", test);
 
            // Gets the handle of the original window
            String originalWindow = driver.getWindowHandle();
            // Switches to the new tab/window that opened
            for (String windowHandle : driver.getWindowHandles()) {
                if (!windowHandle.equals(originalWindow)) {
                    driver.switchTo().window(windowHandle);
                    break;
                }
            }
 
            // Navigates to the Practo medicine order page
            driver.navigate().to("https://www.practo.com/order?utm_source=practonavbar&utm_medium=referral&utm_campaign=pract…");
            Thread.sleep(3000);
            ScreenshotUtil.capture(driver, "Navigated to Practo Order Page", test);
 
            JavascriptExecutor ja = (JavascriptExecutor) driver;
            // Explicitly scrolls down to make the popular medicines visible
            ja.executeScript("window.scrollBy(0,1000)");
            // Waits for the popular medicine titles to be present
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("m-product__title")));
 
            List<String> popularMedicines = new ArrayList<>();
            List<WebElement> Names = driver.findElements(By.className("m-product__title"));
            System.out.println("\nPopular products:");
            ScreenshotUtil.capture(driver, "Popular Medicines Displayed", test);
 
            // Loops through the first 5 popular medicine names
            for (int i = 0; i < Math.min(5, Names.size()); i++) {
                // Highlights the element
                highlightElement(driver, Names.get(i));
                String name = Names.get(i).getText();
                System.out.println((i + 1) + ". " + name);
                popularMedicines.add(name);
                test.log(Status.INFO, "Popular Medicine: " + name);
            }
 
            // Navigates to the contact us page
            driver.get("https://www.practo.com/company/contact");
            ScreenshotUtil.capture(driver, "Navigated to Contact Page", test);
 
            // Finds the dropdown menu
            WebElement dropdown = driver.findElement(By.xpath("//*[@id=\"contactus-form\"]/div[1]/div/div/div[1]/select"));
            // Highlights the element
            highlightElement(driver, dropdown);
            // Selects an option from the dropdown menu
            Select select = new Select(dropdown);
            select.selectByVisibleText("Free trial for a software to manage my clinic");
            ScreenshotUtil.capture(driver, "Dropdown Selected", test);
 
            // Finds the name field and enters text
            WebElement nameField = driver.findElement(By.xpath("//*[@id=\"contactus-form\"]/div[1]/div/div/div[2]/div[2]/input"));
            // Highlights the element
            highlightElement(driver, nameField);
            nameField.sendKeys("raji");
 
            // Finds the phone field and enters text
            WebElement phoneField = driver.findElement(By.xpath("//*[@id=\"contactus-form\"]/div[1]/div/div/div[2]/div[3]/div/input"));
            // Highlights the element
            highlightElement(driver, phoneField);
            phoneField.sendKeys("8736387463874");
            ScreenshotUtil.capture(driver, "Entered Name and Phone", test);
 
            // Finds and clicks the checkbox
            WebElement checkbox = driver.findElement(By.xpath("//*[@id=\"contactus-form\"]/div[1]/div/div/div[2]/div[7]/div[1]/span[1]/label/span"));
            // Highlights the element
            highlightElement(driver, checkbox);
            checkbox.click();
            ScreenshotUtil.capture(driver, "Checkbox Selected", test);
 
            // Finds and clicks the form submission button
            WebElement submitButton = driver.findElement(By.xpath("//*[@id=\"contactus-form\"]/div[2]/input"));
            // Highlights the element
            highlightElement(driver, submitButton);
            submitButton.click();
            ScreenshotUtil.capture(driver, "Form Submitted", test);
 
            // Switches to the iframe to interact with the popup
            WebElement iframe = driver.findElement(By.id("login-iframe-form"));
            driver.switchTo().frame(iframe);
            // Locates and gets the text from the popup element
            WebElement popupElement = driver.findElement(By.xpath("//*[@id='otpSentMsg']"));
            // Highlights the element
            highlightElement(driver, popupElement);
            String popupText = popupElement.getText();
            test.log(Status.INFO, "Popup Text: " + popupText);
            ScreenshotUtil.capture(driver, "Popup Captured", test);
 
            // Prints the popup text to the console
            System.out.println("---------------------------------");
            System.out.println("Popup Text: " + popupText);
 
            // Writes the collected data to an Excel file
            writeToExcel(topHospitals, popularMedicines, "TopHospitals.xlsx");
            test.log(Status.INFO, "Excel Written");
            test.log(Status.PASS, "Test completed successfully.");
 
        } catch (Exception e) {
            // Captures a screenshot and logs the failure in case of an error
            ScreenshotUtil.capture(driver, "Error", test);
            test.log(Status.FAIL, "Test failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
 
    @AfterMethod
    public void tearDownMethod() {
        // Quits the browser driver if it's not null
        if (driver != null) {
            driver.quit();
        }
    }
 
    @AfterSuite
    public void tearDownReport() {
        // Flushes the report to ensure all logs are written
        if (extent != null) {
            extent.flush();
        }
    }
 
    public static void setLocation(WebDriver driver, String city) throws InterruptedException {
        // Finds the location search box
        WebElement location = driver.findElement(By.xpath("//*[@id=\"c-omni-container\"]/div/div[1]/div/input"));
        // Highlights the element
        highlightElement(driver, location);
        // Clicks the search box, clears any existing text, and enters the new city
        location.click();
        driver.findElement(By.className("icon-ic_cross_solid")).click();
        location.sendKeys(city);
        // Navigates and selects the suggested city using keyboard keys
        location.sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(2000);
        location.sendKeys(Keys.ARROW_DOWN);
        location.sendKeys(Keys.ENTER);
    }
 
    public static String[] getTopHospital(WebDriver driver) {
        try {
            // Finds the first hospital card on the page
            WebElement hospitalCard = driver.findElement(By.className("inner"));
            // Highlights the element
            highlightElement(driver, hospitalCard);
            // Extracts the hospital name, timing, and rating
            String name = hospitalCard.findElement(By.tagName("h2")).getText();
            String timing = hospitalCard.findElement(By.className("pd-right-2px-text-green")).getText();
            String ratingText = hospitalCard.findElement(By.className("c-feedback")).getText();
            String rating = ratingText.split(" ")[0];
            // Returns the extracted data as a string array
            return new String[]{name, timing, rating};
        } catch (Exception e) {
            // Returns null if the elements are not found
            return null;
        }
    }
 
    public static void writeToExcel(List<String[]> data, List<String> medicineData, String fileName) throws IOException {
        // Creates a new Excel workbook
        Workbook workbook = new XSSFWorkbook();
 
        // Creates the "Top Hospitals" sheet
        Sheet sheet = workbook.createSheet("Top Hospitals");
        // Creates the header row for the hospital data
        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("City");
        header.createCell(1).setCellValue("Hospital Name");
        header.createCell(2).setCellValue("Timing");
        header.createCell(3).setCellValue("Rating");
 
        int rowCount = 1;
        // Fills the hospital sheet with the collected data
        for (String[] rowData : data) {
            Row row = sheet.createRow(rowCount++);
            for (int i = 0; i < rowData.length; i++) {
                row.createCell(i).setCellValue(rowData[i]);
            }
        }
 
        // Auto-sizes the columns for readability
        for (int i = 0; i < 4; i++) {
            sheet.autoSizeColumn(i);
        }
 
        // Creates the "Popular Medicines" sheet
        Sheet medicineSheet = workbook.createSheet("Popular Medicines");
        // Creates the header row for the medicine data
        Row medHeader = medicineSheet.createRow(0);
        medHeader.createCell(0).setCellValue("Medicine Name");
        medHeader.createCell(1).setCellValue("Quantity");
        medHeader.createCell(2).setCellValue("Unit");
 
        // Populates the medicine sheet with the collected data
        for (int i = 0; i < medicineData.size(); i++) {
            String fullName = medicineData.get(i);
            String nameOnly = fullName;
            String quantity = "";
            String unit = "";
 
            // Uses a regular expression to extract quantity and unit from the medicine name
            Pattern pattern = Pattern.compile("(\\d+)\\s*(ML|GM)", Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(fullName);
            if (matcher.find()) {
                quantity = matcher.group(1);
                unit = matcher.group(2).toUpperCase();
                nameOnly = fullName.replace(matcher.group(0), "").trim();
            }
 
            Row row = medicineSheet.createRow(i + 1);
            row.createCell(0).setCellValue(nameOnly);
            row.createCell(1).setCellValue(quantity);
            row.createCell(2).setCellValue(unit);
        }
 
        // Auto-sizes the columns for the medicine sheet
        for (int i = 0; i < 3; i++) {
            medicineSheet.autoSizeColumn(i);
        }
 
        // Writes the workbook to a file
        try (FileOutputStream outputStream = new FileOutputStream(fileName)) {
            workbook.write(outputStream);
            workbook.close();
            System.out.println("Success: Excel printed successfully " + fileName);
        } catch (Exception e) {
            e.printStackTrace();
            test.log(Status.FAIL, "Failed to write to Excel: " + e.getMessage());
        }
    }
 
    //Highlight method
    public static void highlightElement(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].style.border='3px solid red'", element);
    }
}